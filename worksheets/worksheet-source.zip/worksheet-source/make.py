from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor, Color, black
import fitz
ROOT=Path(__file__).parent
OUT=ROOT.parent/'artifacts'
for n in ['Regular','Bold','SemiBold','Light']: pdfmetrics.registerFont(TTFont(n,str(ROOT/f'Pretendard-{n}.ttf')))
mm=72/25.4; W,H=210*mm,297*mm
c=canvas.Canvas(str(OUT/'gas-lab-worksheet.pdf'),pagesize=(W,H));c.setTitle('효진쌤의 기체 실험실 | 중학교 2학년 탐구 활동지')
C='#BCE1DF'; blue='#AECEE2'
def tone(col,t):
 h=HexColor(col);return Color(1-(1-h.red)*t,1-(1-h.green)*t,1-(1-h.blue)*t)
def rect(x,y,w,h,fill=None,stroke=None,r=0):
 c.setFillColor(HexColor(fill) if isinstance(fill,str) else fill or Color(1,1,1));c.setStrokeColor(HexColor(stroke) if isinstance(stroke,str) else stroke or Color(1,1,1));c.setLineWidth(.6)
 c.roundRect(x*mm,H-(y+h)*mm,w*mm,h*mm,r*mm,fill=1,stroke=bool(stroke))
def text(x,y,s,size=12,font='Regular',color='#000000'):
 c.setFillColor(HexColor(color));c.setFont(font,size);c.drawString(x*mm,H-y*mm,s)
def line(x,y,x2,y2,color='#CCCCCC',width=.5):
 c.setStrokeColor(HexColor(color) if isinstance(color,str) else color);c.setLineWidth(width);c.line(x*mm,H-y*mm,x2*mm,H-y2*mm)
def lines(y,n=2):
 for i in range(n):line(22,y+i*9,188,y+i*9)
def base(num,name,col=C):
 c.bookmarkPage('p'+str(num));c.setLineCap(1);c.setDash(3,5);line(0,18,210,18,tone(col,.4),2);c.setDash()
 if num%2==0:
  rect(0,0,47,18,tone(col,.4));rect(0,16,19,26,tone(col,.4))
  c.saveState();p=c.beginPath();p.moveTo(0,H);p.lineTo(47*mm,H);p.lineTo(47*mm,H-18*mm);p.lineTo(19*mm,H-18*mm);p.lineTo(19*mm,H-42*mm);p.lineTo(0,H-42*mm);p.close();c.clipPath(p,stroke=0)
  for i in range(-50,65,3):line(i,0,i+45,45,col,1.6)
  c.restoreState()
 else:
  text(94,15.8,'2026',9,color=col);text(106,15.8,'효진쌤의 기체 실험실',9,color='#999999')
 if num%2==0:text(20,286,str(num),12,color='#4F4F4F');text(28,286,'…',18,color='#CCCCCC');text(39,286,name,12,color='#999999')
 else:
  text(123,286,name,12,color='#999999');text(175,286,'…',18,color='#CCCCCC');text(186,286,str(num),12,color='#4F4F4F')
def bar(y,n,title,col=C):
 rect(20,y,170,9.5,tone(col,.12),col,4);rect(20,y-.75,11,11,col,col,2.2);text(23,y+6.3,str(n),12,'Bold');text(35,y+6.3,title,12,'Bold')
def section():
 c.setFillColor(tone(C,.3));c.circle(44*mm,H-60.1*mm,24.5*mm,fill=1,stroke=0);c.setFillColor(HexColor(C));c.circle(47*mm,H-62*mm,16*mm,fill=1,stroke=0);text(44,67,'I',44,'Light');text(76.5,57.5,'측정으로 찾는 규칙',26,'Bold');line(76.5,63,190,63,C,2.2);rect(76.5,67,39,8,tone(C,.25),r=4);text(81,72.5,'예상 · 측정 · 해석',12,'Bold')
# cover
rect(0,0,210,297,C);text(20,38,'측정하고, 점을 찍고, 규칙을 발견하다',12,'SemiBold');text(20,58,'2026',16);text(20,108,'효진쌤의',40,'Bold');text(20,129,'기체 실험실',40,'Bold');text(20,155,'압력과 부피 탐구 활동지',20,'SemiBold');line(20,171,190,171,'#FFFFFF',2);text(20,191,'중학교 2학년 · 과학 2차시',14);text(20,227,'학년       반       번호',12);text(20,244,'이름',12);line(35,246,168,246,'#000000');text(20,276,'학생용 · 공식 없이 데이터로 탐구하기',11);c.showPage()
# contents
c.bookmarkPage('p1');text(20,36,'효진쌤의 기체 실험실',11,'SemiBold', '#666666');text(20,48,'C O N T E N T S',9,color='#666666');text(20,70,'목차',34,'Bold')
for y,title,page in [(109,'1차시 | 예상하고 측정하기',2),(137,'2차시 | 점을 모아 해석하기',3),(165,'정리 · 성찰 기록지',4)]:
 text(23,y,title,16,'SemiBold');text(180,y,str(page),16,'Bold');line(23,y+6,190,y+6,C);c.linkRect('',f'p{page}',(20*mm,H-(y+8)*mm,190*mm,H-(y-8)*mm),relative=0,thickness=0)
text(20,202,'준비물',12,'Bold');text(20,214,'시뮬레이션을 실행할 기기, 필기구, 자',12);text(20,238,'진행 순서',12,'Bold');text(20,250,'예상하기 → 측정하기 → 점 찍기 → 설명하기',12);text(104,286,'1',8,color='#8C8C8C');c.showPage()
# activity2
base(2,'탐구 활동');section();bar(95,1,'압력을 바꾸기 전에 예상해요')
text(22,116,'피스톤에 가하는 압력이 커지면 부피는 어떻게 될까요?');text(22,122.2,'그렇게 생각한 까닭을 그림이나 글로 나타내세요.');lines(137,3)
bar(165,2,'조건을 확인하고 측정해요');text(22,186,'온도와 기체의 양은 일정하게 유지합니다.');text(22,192.2,'서로 다른 압력을 골라 5회 이상 측정하고 기록하세요.')
xs=[20,40,90,140,190];y=202
for row in range(7):
 for j in range(4):rect(xs[j],y+row*8.6,xs[j+1]-xs[j],8.6,C if row==0 else '#FFFFFF',tone(C,.6))
 vals=['회차','압력 (atm)','부피 (mL)','관찰 메모'] if row==0 else [str(row),'','','']
 for j,v in enumerate(vals):text(xs[j]+3,y+row*8.6+5.9,v,11 if row==0 else 12,'SemiBold' if row==0 else 'Regular')
c.showPage()
# activity3
base(3,'탐구 활동');bar(36,3,'기록한 측정값을 점으로 나타내요');text(22,57,'기록한 값마다 압력과 부피가 만나는 곳에 점을 찍으세요.');text(22,63.2,'시뮬레이션의 점들과 비교하고, 점들의 배열을 관찰하세요.')
x0,x1,y0,y1=40,183,79,178
for i in range(8):
 x=x0+i*(x1-x0)/7;line(x,y0,x,y1,'#D4D4D4');text(x-3,y1+7,f'{.5+i*.5:.1f}',10)
for i in range(9):
 y=y1-i*(y1-y0)/8;line(x0,y,x1,y,'#D4D4D4');text(29,y+1,str(i*5),10)
line(x0,y0,x0,y1,'#000000',.8);line(x0,y1,x1,y1,'#000000',.8);text(23,75,'부피 (mL)',11);text(160,193,'압력 (atm)',11)
bar(204,4,'데이터를 근거로 설명해요');text(22,224,'압력이 2배인 두 측정값을 골라 부피를 비교하세요.');lines(235,1);text(22,247,'점들은 어떤 모양으로 배열되나요? 측정값을 들어 설명하세요.');lines(258,1);c.showPage()
# standalone form
base(4,'정리 · 성찰',blue);rect(20,42,170,225,None,blue,3);rect(24,38,58,8,blue,r=4);text(28,43.8,'정리 · 성찰 기록지',12,'Bold');text(26,59,'이름:',12);text(110,59,'수업 날짜:',12)
bar(72,1,'우리의 발견',blue);text(26,94,'압력과 부피 사이에서 찾은 규칙을 내 말로 쓰세요.');lines(106,3)
bar(139,2,'새로운 상황에 적용',blue);text(26,160,'압력을 더 크게 바꾸면 부피는 어떻게 될까요?');text(26,166.2,'측정한 데이터를 근거로 예상하고, 실제로 확인하세요.');text(26,180,'예상:',12,'SemiBold');lines(190,1);text(26,204,'확인 결과와 비교:',12,'SemiBold');lines(214,1)
text(26,234,'아직 궁금한 점 또는 더 해 보고 싶은 실험',12,'Bold');lines(246,2);c.showPage()
# back
rect(0,0,210,297,C);text(20,75,'나의 발견은',26,'Bold');text(20,91,'어떤 데이터에서 시작되었나요?',23,'Bold');text(20,227,'자료명',12,'SemiBold');text(20,238,'효진쌤의 기체 실험실 — 압력과 부피 탐구 활동지',12);text(20,255,'대상 · 연도',12,'SemiBold');text(20,266,'중학교 2학년 · 2026',12);c.showPage();c.save()
doc=fitz.open(OUT/'gas-lab-worksheet.pdf')
for i,p in enumerate(doc):p.get_pixmap(matrix=fitz.Matrix(1,1)).save(OUT/f'page-{i+1}.png')
from PIL import Image,ImageOps,ImageDraw
ims=[Image.open(OUT/f'page-{i+1}.png').convert('RGB') for i in range(len(doc))]
preview=Image.new('RGB',(ims[0].width*2,ims[0].height*3),'#dddddd')
for i,im in enumerate(ims):preview.paste(im,((i%2)*im.width,(i//2)*im.height))
preview.thumbnail((1200,1800));preview.save(OUT/'spread-preview.png')
print('Created',len(doc),'pages; internal links:',sum(len(p.get_links()) for p in doc))
for i,p in enumerate(doc):
 assert '\ufffd' not in p.get_text()
 print(i+1, 'text chars',len(p.get_text()),'fonts',len(p.get_fonts()))
